(function(){
"use strict";
const DOMAINS = ['tenant','identity','defender','purview'];
const QUOTAS = {tenant:17,identity:17,defender:19,purview:7};
function random(){const b=new Uint32Array(1);globalThis.crypto.getRandomValues(b);return b[0]/4294967296;}
function shuffle(items,rng=random){const out=[...items];for(let i=out.length-1;i>0;i--){const j=Math.floor(rng()*(i+1));[out[i],out[j]]=[out[j],out[i]];}return out;}
function eligible(bank,{domain='all',includeVisual=true}={}){return bank.filter(q=>(domain==='all'||q.domain===domain)&&(includeVisual||q.kind!=='visual'));}
function sampleQuestions(bank,options={},previousIds=[],rng=random){
 const pool=eligible(bank,options),target=Math.min(options.count??60,pool.length),previous=new Set(previousIds),picked=[];
 const take=(candidates,n)=>{const fresh=shuffle(candidates.filter(q=>!previous.has(q.id)),rng),old=shuffle(candidates.filter(q=>previous.has(q.id)),rng),ordered=[...fresh,...old],selected=[],families=new Set();for(const q of ordered){const family=q.family||q.id;if(!families.has(family)){selected.push(q);families.add(family);if(selected.length===n)return selected;}}const ids=new Set(selected.map(q=>q.id));return [...selected,...ordered.filter(q=>!ids.has(q.id))].slice(0,n);};
 if((options.domain??'all')==='all'&&target===60){for(const d of DOMAINS)picked.push(...take(pool.filter(q=>q.domain===d),QUOTAS[d]));const ids=new Set(picked.map(q=>q.id));if(picked.length<target)picked.push(...take(pool.filter(q=>!ids.has(q.id)),target-picked.length));}
 else picked.push(...take(pool,target));
 return shuffle(picked,rng);
}
function answered(q,response){if(q.kind==='visual')return typeof response==='string'&&response.trim().length>0;if(q.kind==='fields')return q.fields.every(f=>typeof response?.[f.key]==='string'&&response[f.key]);return Array.isArray(response)&&response.length>0;}
function gradeObjective(q,response){if(q.kind==='visual')return null;if(q.kind==='fields')return q.fields.every(f=>response?.[f.key]===f.correct);if(!Array.isArray(response)||new Set(response).size!==response.length)return false;return response.length===q.correct.length&&q.correct.every(k=>response.includes(k));}
function scoreAttempt(questions,responses={},manual={}){
 const rows=questions.map(q=>{const done=answered(q,responses[q.id]);if(q.kind!=='visual')return{id:q.id,domain:q.domain,source:'auto',status:gradeObjective(q,responses[q.id])?'correct':'incorrect',answered:done};const result=manual[q.id];return{id:q.id,domain:q.domain,source:'manual',status:!done?'skipped':result===true?'correct':result===false?'incorrect':'pending',answered:done};});
 const domains=Object.fromEntries(DOMAINS.map(d=>[d,{total:0,correct:0,pending:0}]));for(const r of rows){domains[r.domain].total++;if(r.status==='correct')domains[r.domain].correct++;if(r.status==='pending')domains[r.domain].pending++;}
 const correct=rows.filter(r=>r.status==='correct').length,pending=rows.filter(r=>r.status==='pending').length;
 return{rows,total:rows.length,correct,pending,incorrect:rows.filter(r=>r.status==='incorrect'||r.status==='skipped').length,percent:rows.length?Math.round(correct/rows.length*100):0,automatic:rows.filter(r=>r.source==='auto').length,assisted:rows.filter(r=>r.source==='manual').length,unanswered:rows.filter(r=>!r.answered).length,domains};
}
function cleanStoredAttempt(data,bank){if(!data||data.version!==1||!Array.isArray(data.ids)||data.ids.length===0||data.ids.length>60||new Set(data.ids).size!==data.ids.length)return null;const known=new Set(bank.map(q=>q.id));if(data.ids.some(id=>!known.has(id)))return null;return{...data,index:Math.max(0,Math.min(data.index??0,data.ids.length-1)),responses:data.responses&&typeof data.responses==='object'?data.responses:{},manual:data.manual&&typeof data.manual==='object'?data.manual:{},flags:Array.isArray(data.flags)?data.flags.filter(id=>known.has(id)):[]};}

function parseCSV(input){
 const text=String(input).replace(/^\uFEFF/,''),first=text.split(/\r?\n/,1)[0],delimiter=(first.match(/;/g)||[]).length>=(first.match(/,/g)||[]).length?';':',';
 const rows=[];let row=[],field='',quoted=false;
 for(let i=0;i<text.length;i++){const c=text[i];if(quoted){if(c==='"'&&text[i+1]==='"'){field+='"';i++;}else if(c==='"')quoted=false;else field+=c;}else if(c==='"'&&field==='')quoted=true;else if(c===delimiter){row.push(field);field='';}else if(c==='\n'||c==='\r'){if(c==='\r'&&text[i+1]==='\n')i++;row.push(field);if(row.some(x=>x.trim()!==''))rows.push(row);row=[];field='';}else field+=c;}
 if(quoted)throw new Error('CSV: campo entre aspas não foi fechado.');if(field!==''||row.length){row.push(field);if(row.some(x=>x.trim()!==''))rows.push(row);}
 if(rows.length<2)throw new Error('CSV vazio ou sem registros.');const headers=rows.shift().map(x=>x.trim());if(new Set(headers).size!==headers.length)throw new Error('CSV com cabeçalhos duplicados.');return rows.map((values,i)=>{if(values.length!==headers.length)throw new Error(`CSV: linha ${i+2} tem ${values.length} campos; esperados ${headers.length}.`);return Object.fromEntries(headers.map((key,j)=>[key,values[j]]));});
}
function bankFromCSV(input){
 const rows=parseCSV(input),questions=[],cases=[],ids=new Set(),validKinds=['single','multiple','visual','fields'];
 const assets=value=>(value||'').split('|').map(x=>x.trim()).filter(Boolean).map(path=>{if(!/^assets\/[a-zA-Z0-9_\-/]+\.(webp|png|jpg|jpeg|svg)$/.test(path)||path.includes('..'))throw new Error('CSV: caminho de imagem inválido.');return path;});
 for(const r of rows){if(!r.registro||!r.id)throw new Error('CSV: faltam as colunas registro ou id.');if(ids.has(r.id))throw new Error(`CSV: identificador duplicado ${r.id}.`);ids.add(r.id);
  if(r.registro==='caso')throw new Error('CSV: esta edição usa apenas questões autorais em texto.');
  if(r.registro!=='questao')throw new Error('CSV: registro deve ser questao ou caso.');
  if(!Number.isInteger(Number(r.numero))||Number(r.numero)<1)throw new Error(`CSV: número inválido em ${r.id}.`);
  if(r.autoria!=='autoral-v1'||r.tipo!=='single'||(r.originais||'').trim()||r.figuras||r.figuras_gabarito)throw new Error('CSV: use apenas questões autorais em texto desta edição.');
  if(!/^q\d{3,5}$/.test(r.id)||!DOMAINS.includes(r.dominio)||!validKinds.includes(r.tipo)||!r.enunciado_en?.trim()||!r.enunciado_pt?.trim())throw new Error(`CSV: questão ${r.id} está incompleta ou tem domínio/tipo inválido.`);
  const choices=[];for(const key of 'ABCDEFGHIJK'){const en=r[`alternativa_${key.toLowerCase()}_en`],pt=r[`alternativa_${key.toLowerCase()}_pt`];if(en){if(!pt)throw new Error(`CSV: alternativa ${key} de ${r.id} sem português.`);choices.push({key,text_en:en,text_pt:pt});}}
  const correct=(r.gabarito||'').split('|').map(x=>x.trim()).filter(Boolean);let fields=[];try{fields=r.campos_json?JSON.parse(r.campos_json):[];}catch{throw new Error(`CSV: campos_json inválido em ${r.id}.`);}
  if(['single','multiple'].includes(r.tipo)&&(!correct.length||choices.length!==4||new Set(correct).size!==correct.length||correct.some(k=>!choices.find(o=>o.key===k))||(r.tipo==='single'&&correct.length!==1)))throw new Error(`CSV: gabarito inválido em ${r.id}.`);
  if(r.tipo==='fields'&&(!Array.isArray(fields)||!fields.length||new Set(fields.map(f=>f.key)).size!==fields.length||fields.some(f=>!f.key||!f.label_en||!f.label_pt||!Array.isArray(f.options)||!f.options.find(o=>o.key===f.correct)||f.options.some(o=>!o.key||!o.text_en||!o.text_pt))))throw new Error(`CSV: campos ou gabarito incompletos em ${r.id}.`);
  const answerFigures=assets(r.figuras_gabarito);if(r.tipo==='visual'&&!answerFigures.length&&!r.resposta_en?.trim())throw new Error(`CSV: questão visual ${r.id} sem resposta de referência.`);
  let refs=[];try{refs=r.fontes_json?JSON.parse(r.fontes_json):[];}catch{throw new Error('CSV: fontes_json inválido.');}if(!Array.isArray(refs)||!refs.length||refs.some(url=>typeof url!=='string'||!/^https:\/\/(learn\.microsoft\.com|support\.microsoft\.com|techcommunity\.microsoft\.com)\//.test(url)))throw new Error('CSV: referência oficial inválida.');if(!r.familia?.trim()||!r.tema?.trim()||!r.explicacao_pt?.trim()||!r.explicacao_en?.trim())throw new Error('CSV: falta família, tema ou explicação.');
  questions.push({family:r.familia,topic:r.tema,refs,id:r.id,number:Number(r.numero),originalIds:(r.originais||'').split('|').filter(Boolean).map(Number),domain:r.dominio,kind:r.tipo,prompt_en:r.enunciado_en,prompt_pt:r.enunciado_pt,choices,correct,fields,figures:assets(r.figuras),figureText_en:r.figuras_texto_en||'',figureText_pt:r.figuras_texto_pt||'',answerFigures,expected_en:r.resposta_en||'',expected_pt:r.resposta_pt||'',explanation_en:r.explicacao_en||'',explanation_pt:r.explicacao_pt||'',note_pt:r.nota_pt||'',note_en:r.nota_en||'',caseId:r.caso_id?Number(r.caso_id):null,reviewed:r.revisada==='1'});
 }
 if(!questions.length)throw new Error('CSV não contém questões.');for(const q of questions)if(q.caseId&&!cases.some(c=>c.id===q.caseId))throw new Error(`CSV: o estudo de caso ${q.caseId} de ${q.id} não foi encontrado.`);
 return{version:'csv-v1',questions,cases};
}

window.MS102Core = {DOMAINS,QUOTAS,random,shuffle,eligible,sampleQuestions,answered,gradeObjective,scoreAttempt,cleanStoredAttempt,parseCSV,bankFromCSV};
})();
